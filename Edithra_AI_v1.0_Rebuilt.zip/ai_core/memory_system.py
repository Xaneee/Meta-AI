
# Edithra AI - Memory System (Rebuilt)
# Manages AI's ability to remember past interactions

class EdithraAIMemory:
    def __init__(self):
        self.memory = []

    def store_experience(self, experience):
        self.memory.append(experience)
        return f"Memory Stored: {experience}"

    def recall_memory(self):
        return self.memory[-1] if self.memory else "No Memory Available"

if __name__ == "__main__":
    memory = EdithraAIMemory()
    print(memory.store_experience("AI Debugging Test"))
    print(memory.recall_memory())
