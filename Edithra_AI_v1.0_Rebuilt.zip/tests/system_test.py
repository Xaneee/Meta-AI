
# Edithra AI - Automated System Tests (Rebuilt)

from ai_core.memory_system import EdithraAIMemory
from ai_core.decision_making import EdithraAIThinking
from ai_core.self_optimization import EdithraAIExecution

# Test AI Memory System
def test_ai_memory():
    memory = EdithraAIMemory()
    memory.store_experience("AI Debugging Test")
    return "✅ AI Memory Test Passed" if memory.recall_memory() == "AI Debugging Test" else "❌ AI Memory Test Failed"

# Test AI Decision-Making
def test_ai_decision_making():
    thinking = EdithraAIThinking()
    result = thinking.analyze_problem("Improve API speed")
    return "✅ AI Decision-Making Test Passed" if "Analyzed" in result else "❌ AI Decision-Making Test Failed"

# Test AI Self-Optimization
def test_ai_self_optimization():
    execution = EdithraAIExecution()
    before_optimization = execution.optimization_level
    execution.self_optimize()
    return "✅ AI Self-Optimization Test Passed" if execution.optimization_level > before_optimization else "❌ AI Self-Optimization Test Failed"

# Run Tests
if __name__ == "__main__":
    print(test_ai_memory())
    print(test_ai_decision_making())
    print(test_ai_self_optimization())
