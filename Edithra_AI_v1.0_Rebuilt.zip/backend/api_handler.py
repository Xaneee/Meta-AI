
# Edithra AI - Backend API Handler (Rebuilt)
# Handles API requests and connects to AI core

from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/process', methods=['POST'])
def process_request():
    data = request.json
    response = {"message": f"Processing request: {data}"}
    return jsonify(response)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
